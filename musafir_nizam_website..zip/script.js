function updateClock() {
  const places = {
    india: 'Asia/Kolkata',
    usa: 'America/New_York',
    japan: 'Asia/Tokyo'
  };

  const clockDiv = document.getElementById('world-clock');
  clockDiv.innerHTML = '';

  for (const place in places) {
    const time = new Date().toLocaleString('en-US', { 
      timeZone: places[place], 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit',
      weekday: 'long',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
    const div = document.createElement('div');
    div.textContent = `${place.toUpperCase()}: ${time}`;
    clockDiv.appendChild(div);
  }
}

setInterval(updateClock, 1000);
updateClock();

function showInfo(country) {
  const info = {
    india: "🇮🇳 India - Capital: New Delhi, Famous Places: Taj Mahal, Ladakh, Kerala",
    usa: "🇺🇸 USA - Capital: Washington D.C., Famous Places: Grand Canyon, NYC, LA",
    japan: "🇯🇵 Japan - Capital: Tokyo, Famous Places: Mount Fuji, Kyoto, Osaka"
  };
  document.getElementById('country-info').textContent = info[country];
}
