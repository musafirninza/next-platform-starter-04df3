
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("loader").style.display = "none";
  const worldTimes = {
    "New York": "America/New_York",
    "London": "Europe/London",
    "Delhi": "Asia/Kolkata",
    "Tokyo": "Asia/Tokyo",
    "Sydney": "Australia/Sydney"
  };
  const container = document.getElementById("world-times");
  setInterval(() => {
    container.innerHTML = '';
    for (const [city, zone] of Object.entries(worldTimes)) {
      const time = new Date().toLocaleString("en-US", { timeZone: zone });
      container.innerHTML += `<p><strong>${city}</strong>: ${time}</p>`;
    }
  }, 1000);
});
